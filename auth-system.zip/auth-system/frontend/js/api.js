// js/api.js
// Small fetch wrapper shared by login/register/dashboard pages.
// credentials: "include" is required so the httpOnly cookie is sent
// with each request.

const API_BASE = "/api";

async function apiRequest(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  let body = null;
  try {
    body = await res.json();
  } catch (_) {
    // no JSON body
  }

  if (!res.ok) {
    const message = body?.error || "Something went wrong. Please try again.";
    const err = new Error(message);
    err.status = res.status;
    throw err;
  }

  return body;
}

const api = {
  register: (payload) => apiRequest("/auth/register", { method: "POST", body: JSON.stringify(payload) }),
  login: (payload) => apiRequest("/auth/login", { method: "POST", body: JSON.stringify(payload) }),
  logout: () => apiRequest("/auth/logout", { method: "POST" }),
  me: () => apiRequest("/auth/me"),
  dashboard: () => apiRequest("/dashboard"),
};
