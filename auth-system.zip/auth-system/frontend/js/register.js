// js/register.js

(function () {
  "use strict";

  const form = document.getElementById("register-form");
  const alertBox = document.getElementById("alert");
  const submitBtn = document.getElementById("submit-btn");

  function showAlert(message, type) {
    alertBox.textContent = message;
    alertBox.className = `alert show ${type}`;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    alertBox.className = "alert";

    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    if (password !== confirmPassword) {
      showAlert("Passwords don't match.", "error");
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = "Creating account…";

    try {
      await api.register({ username, email, password });
      window.location.href = "dashboard.html";
    } catch (err) {
      showAlert(err.message, "error");
      submitBtn.disabled = false;
      submitBtn.textContent = "Create account";
    }
  });
})();
