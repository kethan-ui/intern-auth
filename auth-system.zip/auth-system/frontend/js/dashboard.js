// js/dashboard.js
// Protected page: confirms the session with GET /api/auth/me before
// rendering anything. If that call 401s, the httpOnly cookie is
// missing/expired/invalid, so we redirect to login.

(function () {
  "use strict";

  const nameEl = document.getElementById("user-name");
  const emailEl = document.getElementById("user-email");
  const joinedEl = document.getElementById("user-joined");
  const expEl = document.getElementById("session-exp");
  const logoutBtn = document.getElementById("logout-btn");
  const loadingEl = document.getElementById("loading-state");
  const contentEl = document.getElementById("dashboard-content");

  async function init() {
    try {
      const { user } = await api.me();
      const dash = await api.dashboard();

      nameEl.textContent = user.username;
      emailEl.textContent = user.email;
      joinedEl.textContent = new Date(dash.servedAt).toLocaleString();

      if (user.exp) {
        expEl.textContent = new Date(user.exp * 1000).toLocaleString();
      } else {
        expEl.textContent = "—";
      }

      loadingEl.hidden = true;
      contentEl.hidden = false;
    } catch (err) {
      // Not authenticated (or session expired) — bounce to login.
      window.location.href = "login.html";
    }
  }

  logoutBtn.addEventListener("click", async () => {
    logoutBtn.disabled = true;
    logoutBtn.textContent = "Logging out…";
    try {
      await api.logout();
    } finally {
      window.location.href = "login.html";
    }
  });

  init();
})();
