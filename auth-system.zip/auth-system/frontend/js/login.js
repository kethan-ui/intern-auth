// js/login.js

(function () {
  "use strict";

  const form = document.getElementById("login-form");
  const alertBox = document.getElementById("alert");
  const submitBtn = document.getElementById("submit-btn");

  function showAlert(message, type) {
    alertBox.textContent = message;
    alertBox.className = `alert show ${type}`;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    alertBox.className = "alert";

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    submitBtn.disabled = true;
    submitBtn.textContent = "Logging in…";

    try {
      await api.login({ email, password });
      window.location.href = "dashboard.html";
    } catch (err) {
      showAlert(err.message, "error");
      submitBtn.disabled = false;
      submitBtn.textContent = "Log in";
    }
  });
})();
