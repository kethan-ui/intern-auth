# Authentication System

A secure registration/login system built for **Task 3: Authentication System**
(WeIntern Pvt Ltd — Full Stack Development, Week 2).

**Live demo:** _add your deployed link here (backend needs a Node host — see Deploying below)_

## Project purpose

Registration, login, and session management with the security practices the handbook calls
for: hashed passwords, JWT sessions, protected routes, and safe error messaging.

## Tech stack

| Layer        | Choice                                   |
|--------------|--------------------------------------------|
| Frontend     | HTML5, CSS3, vanilla JavaScript (fetch API) |
| Backend      | Node.js + Express 5                        |
| Database     | SQLite via `better-sqlite3`                |
| Password hashing | `bcryptjs` (10 salt rounds)             |
| Sessions     | JWT (`jsonwebtoken`), stored in an **httpOnly cookie** |

## Security notes

- **Passwords are never stored in plaintext** — only a bcrypt hash (`password_hash` column).
  Verified manually: hashes in the DB start with `$2b$10$…`.
- **JWT in an httpOnly cookie, not `localStorage`.** Client-side JS can't read an httpOnly
  cookie, so a successful XSS injection can't steal the session token the way it could if the
  token sat in `localStorage`. The cookie is also `sameSite: "lax"` and flagged `secure` in
  production (HTTPS only).
- **Generic login error message.** "Invalid email or password" is returned whether the email
  doesn't exist or the password is wrong — this prevents an attacker from using the login
  endpoint to discover which emails have accounts (user enumeration).
- **Login rate limiting.** After 5 failed attempts for the same email, the endpoint returns
  `429` for 30 seconds. This is in-memory (per server process) — fine for a single instance;
  a multi-instance deployment would move this to Redis or similar.
- **Server-side validation** on registration: username ≥3 chars, valid email format, password
  ≥8 chars, and a duplicate check on both email and username before insert.
- **`requireAuth` middleware** verifies the JWT signature and expiry on every protected
  request — `/api/auth/me` and `/api/dashboard` both use it, so adding a new protected route
  is one line (`router.get("/x", requireAuth, handler)`).
- **JWT secret** is read from `process.env.JWT_SECRET` (see `.env.example`) — never commit a
  real secret; the fallback in code is dev-only and clearly marked as such.

## Features

- Registration with username, email, password + confirm-password (client-side match check)
- Login with generic error messaging (no user enumeration)
- Logout clears the session cookie server-side
- Protected dashboard page — checks the session via `GET /api/auth/me` before rendering
  anything, redirects to login if unauthenticated or the session expired
- 2-hour token expiry (shown on the dashboard as "Session expires")
- Handles edge cases: wrong password, non-existent email, duplicate registration, weak
  password, missing fields, too many failed logins

## API endpoints

| Method | Endpoint             | Auth required | Description |
|--------|------------------------|:---:|--------------|
| POST   | `/api/auth/register`   | No  | Create account, hash password, start session |
| POST   | `/api/auth/login`      | No  | Verify credentials, start session |
| POST   | `/api/auth/logout`     | No  | Clear the session cookie |
| GET    | `/api/auth/me`         | Yes | Return the current user from the verified JWT |
| GET    | `/api/dashboard`       | Yes | Example protected resource |
| GET    | `/api/health`          | No  | Health check |

Postman collection: `postman/auth.postman_collection.json` (Postman's cookie jar handles the
session cookie automatically between requests).

## Database schema

```sql
CREATE TABLE users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT NOT NULL UNIQUE,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
```

## File structure

```
auth-system/
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   ├── db/
│   │   └── database.js        Schema (users table)
│   ├── middleware/
│   │   └── auth.js            requireAuth — verifies JWT from cookie
│   ├── routes/
│   │   ├── auth.js            register / login / logout / me + rate limiting
│   │   └── dashboard.js       Example protected route
│   └── data/
│       └── auth.db            SQLite file (created on first run — gitignored)
├── frontend/
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html         Protected page
│   ├── css/style.css
│   └── js/
│       ├── api.js             fetch wrapper (credentials: "include")
│       ├── login.js
│       ├── register.js
│       └── dashboard.js       Checks session, redirects if unauthenticated
├── postman/
│   └── auth.postman_collection.json
├── screenshots/
└── README.md
```

## Setup / run instructions

```bash
cd backend
npm install
cp .env.example .env   # optional but recommended — set a real JWT_SECRET
npm start
```

Then open **http://localhost:5000** — it redirects to the login page. Register a new
account, and you'll be taken straight to the protected dashboard.

To reset all users, stop the server and delete `backend/data/auth.db` (and `-wal`/`-shm`
files if present).

## Testing the flows

This was tested end-to-end with curl before packaging, covering: register → duplicate email
(409) → invalid input (400) → `/me` with a valid cookie → logout → `/me` after logout (401)
→ wrong password (401, generic message) → non-existent email (401, same message) → correct
login → protected `/api/dashboard` with and without a cookie → 5 failed attempts followed by
a 429 lockout on the 6th.

```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"jsmith","email":"jsmith@example.com","password":"SecurePass1"}' \
  -c cookies.txt

curl http://localhost:5000/api/auth/me -b cookies.txt
```

## Before submitting

- [ ] Record a short demo video: registration → login → protected dashboard → logout
- [ ] If deploying, host the backend on Render/Railway/Fly.io (needs a persistent Node
      process) and set a real `JWT_SECRET` + `NODE_ENV=production` there
- [ ] Update the live demo link above
