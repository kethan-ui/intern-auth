// routes/auth.js
// Registration, login, logout, and current-user endpoints.
// Passwords hashed with bcrypt; sessions handled via a JWT stored in
// an httpOnly cookie (not readable by client-side JS — mitigates XSS
// token theft, unlike localStorage).

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db/database");
const { requireAuth, JWT_SECRET } = require("../middleware/auth");

const router = express.Router();

const SALT_ROUNDS = 10;
const TOKEN_TTL = "2h";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// ---- Simple in-memory login rate limiter ----
// Locks out an email after 5 failed attempts for 30 seconds.
// A production system would use Redis or similar for this across instances.
const failedAttempts = new Map(); // email -> { count, lockedUntil }
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 30 * 1000;

function isLockedOut(email) {
  const entry = failedAttempts.get(email);
  if (!entry) return false;
  if (entry.lockedUntil && entry.lockedUntil > Date.now()) return true;
  if (entry.lockedUntil && entry.lockedUntil <= Date.now()) {
    failedAttempts.delete(email);
  }
  return false;
}

function recordFailure(email) {
  const entry = failedAttempts.get(email) || { count: 0, lockedUntil: null };
  entry.count += 1;
  if (entry.count >= MAX_ATTEMPTS) {
    entry.lockedUntil = Date.now() + LOCKOUT_MS;
  }
  failedAttempts.set(email, entry);
}

function clearFailures(email) {
  failedAttempts.delete(email);
}

function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 2 * 60 * 60 * 1000, // 2 hours, matches TOKEN_TTL
  };
}

/** POST /api/auth/register */
router.post("/register", async (req, res) => {
  const { username, email, password } = req.body || {};
  const errors = [];

  if (!username || username.trim().length < 3) {
    errors.push("Username must be at least 3 characters.");
  }
  if (!email || !EMAIL_RE.test(email)) {
    errors.push("A valid email is required.");
  }
  if (!password || password.length < 8) {
    errors.push("Password must be at least 8 characters.");
  }
  if (errors.length) {
    return res.status(400).json({ error: errors.join(" ") });
  }

  const existing = db
    .prepare("SELECT id FROM users WHERE email = ? OR username = ?")
    .get(email, username);

  if (existing) {
    return res.status(409).json({ error: "An account with that email or username already exists." });
  }

  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

  const result = db
    .prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)")
    .run(username.trim(), email.trim().toLowerCase(), passwordHash);

  const user = { id: result.lastInsertRowid, username: username.trim(), email: email.trim().toLowerCase() };

  const token = jwt.sign(user, JWT_SECRET, { expiresIn: TOKEN_TTL });
  res.cookie("token", token, cookieOptions());

  res.status(201).json({ user });
});

/** POST /api/auth/login */
router.post("/login", async (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  const normalizedEmail = email.trim().toLowerCase();

  if (isLockedOut(normalizedEmail)) {
    return res.status(429).json({
      error: "Too many failed attempts. Please wait 30 seconds before trying again.",
    });
  }

  const row = db.prepare("SELECT * FROM users WHERE email = ?").get(normalizedEmail);

  // Same error for "no such user" and "wrong password" — don't leak
  // which one failed, so an attacker can't enumerate valid emails.
  const invalidMsg = "Invalid email or password.";

  if (!row) {
    recordFailure(normalizedEmail);
    return res.status(401).json({ error: invalidMsg });
  }

  const matches = await bcrypt.compare(password, row.password_hash);
  if (!matches) {
    recordFailure(normalizedEmail);
    return res.status(401).json({ error: invalidMsg });
  }

  clearFailures(normalizedEmail);

  const user = { id: row.id, username: row.username, email: row.email };
  const token = jwt.sign(user, JWT_SECRET, { expiresIn: TOKEN_TTL });
  res.cookie("token", token, cookieOptions());

  res.json({ user });
});

/** POST /api/auth/logout */
router.post("/logout", (req, res) => {
  res.clearCookie("token", { ...cookieOptions(), maxAge: 0 });
  res.json({ message: "Logged out." });
});

/** GET /api/auth/me — protected: confirms the session is valid */
router.get("/me", requireAuth, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
