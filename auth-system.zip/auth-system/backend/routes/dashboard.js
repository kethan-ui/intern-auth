// routes/dashboard.js
// A stand-in "protected resource" — anything behind requireAuth
// demonstrates the middleware guarding real application data.

const express = require("express");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.get("/", requireAuth, (req, res) => {
  res.json({
    message: `Welcome back, ${req.user.username}.`,
    user: req.user,
    servedAt: new Date().toISOString(),
  });
});

module.exports = router;
